package employee;

public interface UI {
	public void insertEmployee();
	public void updateEmployee();
	public void deletEmployee();
	public void findEmployee();
	public void printMainMenu();
}