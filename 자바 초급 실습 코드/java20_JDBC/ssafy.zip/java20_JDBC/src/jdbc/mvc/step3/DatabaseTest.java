package jdbc.mvc.step3;

import java.sql.SQLException;
import java.util.ArrayList;

import config.ServerInfo;

public class DatabaseTest {

	public static void main(String[] args) throws Exception {
		DatabaseDAO dao=DatabaseDAO.getInstance();
		/*try {
			dao.addMember(new Member("333", "아이유", "여의도"));
			
		}catch(SQLException e) {
			System.out.println("등록 실패..");
		}*/
		
		//dao.updateMember(new Member("123", "석용", "제주"));
		
		//dao.deleteMember("123");
		
		//ArrayList<Member> returnList = dao.getAllMember();		
		for(Member m : dao.getAllMember()) {
			System.out.println(m);
		}
		
		

	}
	
	static {
		try {
			Class.forName(ServerInfo.DRIVER_NAME);
			System.out.println("드라이버 로딩 성공...");
		}catch(ClassNotFoundException e) {
			System.out.println("드라이버 로딩 실패...");
		}
	}
}
