package jdbc.mvc.step3;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.sun.xml.internal.ws.api.model.MEP;

import config.ServerInfo;

/*
 * 디비 접근하는 비지니스 로직만 작성...
 * 서버사이드에서 오직 하나만 존재하는 클래스...
 * 클라이언트의 요청이 아무리 많더라고
 * 해당 DAO 의 메소드가 클라이언트의 요청을 처리하는 단독 루틴이 된다.
 * 그 말은 메소드 마다마다 각각 디비서버와의 연결이 이뤄지고
 * 메소드가 끝날때 연결이 끊어지는 메카니즘을 잘 이해할 필요가 있다.
 * ::
 * DAO 소스코드의 흐름을 보면,
 * 비지니스로직 매소드마다 반복되는 부분이 있다.
 * 1) 고정적인 반복
 *     -  디비연결 Connection 리턴
 *     -  자원반납 close()
 * 2) 가변적인 반복
 * 
 */
public class DatabaseDAO {
	private static DatabaseDAO  dao = new DatabaseDAO();
	private DatabaseDAO() {
		
		
	}
	public static DatabaseDAO getInstance() {
		return dao;
	}
	//고정적으로 반복되는 기능을 정의...비지니스 로직에서는 정의된 기능을 호출...
	public Connection getConnect() throws SQLException{
		Connection conn = DriverManager.getConnection(ServerInfo.URL, ServerInfo.USER, ServerInfo.PASS);
		System.out.println("디비연결 성공...");
		
		return conn;
	}
	
	public void closeAll(PreparedStatement ps, Connection conn)  throws SQLException{
		if(ps!=null) ps.close();
		if(conn!=null) conn.close();
	}
	
	public void closeAll(ResultSet rs,PreparedStatement ps, Connection conn)  throws SQLException{
		if(rs!=null) rs.close();
		closeAll(ps, conn);
		
	}
	
	
	//비지니스 로직을 정의
	public void addMember(Member mem) throws SQLException{
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			
			conn = getConnect();
			String query = "INSERT INTO member (id, name, address) VALUES(?, ?,?)";
			ps = conn.prepareStatement(query);
			
			ps.setString(1, mem.getId());
			ps.setString(2, mem.getName());
			ps.setString(3,mem.getAddress());
		
			System.out.println(ps.executeUpdate()+" ros INSERT OK!!");
		}finally {
			closeAll(ps, conn);
		}
	}//
	
	public ArrayList<Member> getAllMember() throws SQLException{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Member> list = new ArrayList<>();
		
		try {
			conn = getConnect();
			
			String query = "SELECT id, name, address FROM member";
			ps = conn.prepareStatement(query);
			
			rs = ps.executeQuery(); //
			while(rs.next()) {
				list.add(new Member(rs.getString("id"), 
									rs.getString("name"), 
									rs.getString("address")));
			}
		}finally {
			closeAll(rs, ps, conn);
		}
		return list;
		
	}//
	
	public void updateMember(Member mem)throws SQLException{
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			
			String query = "UPDATE member SET name=? , address=? WHERE id=?";
			ps = conn.prepareStatement(query);
			
			ps.setString(1, mem.getName());
			ps.setString(2, mem.getAddress());
			ps.setString(3, mem.getId());
			
			System.out.println(ps.executeUpdate()+" row UPDATE OK!!!");
		}finally {
			closeAll(ps, conn);
		}
	}
	
	public void deleteMember(String id) throws SQLException{
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			String query = "DELETE FROM member WHERE id=?";
			ps = conn.prepareStatement(query);
			ps.setString(1, id);
			System.out.println(ps.executeUpdate()+" row DELETE OK!!");
		}finally {
			closeAll(ps, conn);
		}
	}

}


























