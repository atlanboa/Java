package jdbc.step1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/*
 * 데이타베이스 서버에 연결
 * 쿼리문을 실행하기 위한 준비작업을 위한
 * 로직을 작성
 * ::
 * JDBC 4단계:
 * 1. 서버에 대한 정보를 가지고 있는 Driver를 메모리에 로딩
 * 2. 디비서버에 연결 - - Connection 객체를 리턴 받는다. Connection conn=DriverManager.getConnection(url,root, 1234);
 * 3. PreparedStatement를 하나 생성   - - - PreparedStatement ps=conn.prepareStatement("쿼리문");
 * 4. 쿼리문을 실행    (디비에 실질적으로 반영됨)
 *    1) int row=ps.executeUpdate()  :: DML  
 *    2) ResultSet rs=ps.executeQuery()  :: SELECT 
 */
public class DBConnect {
	
	public DBConnect(){		
		try {
			//1.드라이버 로딩
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("1. Driver Loading Success....");
			
			//2.디비서버 연결
			String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUnicode=yes&characterEncoding=UTF-8";
			String user = "root";
			String password = "1234";
			Connection conn=DriverManager.getConnection(url, user, password);
			System.out.println("2. DB Server Connection Success....");
			
			//3. PreparedStatement 생성...쿼리문이 인자값으로 들어감.
			String query = "INSERT INTO member (id, name, address) VALUES(?, ?,?)";
			PreparedStatement ps=conn.prepareStatement(query);
			System.out.println("3. PreparedStatement Creating....");
			
			ps.setString(1, "111");
			ps.setString(2, "효리");
			ps.setString(3, "제주");
			
			//4. 쿼리문 실행
			System.out.println(ps.executeUpdate()+" row INSERT OK!!");
			
		} catch (ClassNotFoundException e) {
			System.out.println(e);
			System.out.println("1. Driver Loading Fail....");
		}catch(SQLException e) {
			System.out.println(e);
			System.out.println("2. DB Server Connection Fail....");
		}
	}
	public static void main(String[] args) {
		new DBConnect();
	}
}



















