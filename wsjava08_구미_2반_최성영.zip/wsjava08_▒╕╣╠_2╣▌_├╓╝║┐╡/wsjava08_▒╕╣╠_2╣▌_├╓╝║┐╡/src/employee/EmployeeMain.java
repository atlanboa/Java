package employee;

public class EmployeeMain {

	public static void main(String[] args) {
		new EmployeeUI();
	}

}
